package stepdefs;

public class Student {
	
public String Name;
public String Job;
public Integer Empid;

public String getName() {
	return Name;
	
}
public void setName(String Name) {
	this.Name=Name;
	
}
public Integer getEmpid() {
	return Empid;
	
}
public Integer setEmpId() {
	this.Empid=Empid;
}
}
