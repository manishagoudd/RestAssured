package stepdefs;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matcher;

import java.util.Map;
import java.util.*;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class TestStepDef {

    private Response response;
    private ValidatableResponse json;
    private RequestSpecification request;
    @Given("^a user sends the response$")
    public void getRequest(){
      given()
      .when()
      .get("http://localhost:3000/students");
      
    }
    @Then("^validate the response$")
    public void getValidation(){
    	given()
    	.when()
    	.then()
    	.statusCode(200)
    	.body("Response.course[0]",equalTo("Java"));
    	//System.out.println(log.all());
    	System.out.println("Hi all");
    	
    }
    
}